<?php
if (!defined('ABSPATH')) { exit; }
interface RSP_Module_Interface { public function init(); }
