=== Ready Secure Pro ===
Contributors: readystudio
Tags: security, login, hardening, headers, firewall, two-factor, rate limit, integrity
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.6.0
License: GPLv2 or later

A modular security suite for WordPress by Ready Studio with beautiful admin UI. Includes login URL change, brute-force, security headers, REST guard, light WAF, 2FA (TOTP), file integrity (core checksums), FS permission scan, logs, and settings import/export.
